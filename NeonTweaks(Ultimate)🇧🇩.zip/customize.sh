#!/system/bin/sh
SCRIPT_PARENT_PATH="$MODPATH/system/bin"
SCRIPT_NAME="neontweaks"
SCRIPT_PATH="$SCRIPT_PARENT_PATH/$SCRIPT_NAME"
set_perm_recursive "$SCRIPT_PATH" root root 0777 0755
set_perm $MODPATH/system/bin/gpumaximize 0 0 0777
ui_print ""
ui_print "     ################################"
ui_print "     #                              #"
ui_print "     |      ★彡 NeonTweaks​​​​​ 彡★     |"
ui_print "     #                              #"
ui_print "     ################################"
ui_print ""
