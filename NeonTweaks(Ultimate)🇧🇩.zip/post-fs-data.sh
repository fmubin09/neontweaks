#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

#zramswap
sleep 10
echo 4096M >/sys/block/zram0/disksize
mkswap /sdcard/zram0/
swapon  /sdcard/zram0/
# Virtual memory tweaks
stop perfd
echo '160' > /proc/sys/vm/swappiness
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '100' > /proc/sys/vm/vfs_cache_pressure
echo '4096' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '4096' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '8000' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '100' > /proc/sys/vm/dirty_ratio
echo '100' > /proc/sys/vm/dirty_background_ratio
chmod 1032 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '38912,40960,43008,45056,47104,49152' > /sys/module/lowmemorykiller/parameters/minfree
rm /data/system/perfd/default_values
start perfd
sleep 20
#run_fstrim    
    sleep 100
fstrim -v /cache
fstrim -v /data
fstrim -v /system
sleep 20